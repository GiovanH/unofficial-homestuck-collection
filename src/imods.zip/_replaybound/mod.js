module.exports = {
    title: "Openbound Enhancements", 
    desc: "Run Openbound at 60fps. Some developer mode cheats.",
    author: "Gio",
    modVersion: 0.1,
    locked: "007163",

    routes: {
        "assets://storyfiles/hs2/05260/Sburb.min.js": "./Sburb.dev.js",
        "assets://storyfiles/hs2/05305/Sburb.min.js": "./Sburb.dev.js",
        "assets://storyfiles/hs2/05395/Sburb.min.js": "./Sburb.dev.js"
    },
}